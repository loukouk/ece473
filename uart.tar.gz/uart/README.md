hd44780_driver
==============

C and header files for controlling HD44780 LCD displays

This is a continuing work of LCD driver routines that work with the 
Hitachi HD44780 LCD driver IC.  Presently it supports the SPI protocol
available on the OSU AVR Mega128 board as well as the commonly used
4-bit protocol. The header file must be altered to support the two
configurations appropriately.
